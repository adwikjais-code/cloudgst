#!/usr/bin/env bash
# PC / laptop par bridge chalane ke liye:  ./run-local.sh
set -e
cd "$(dirname "$0")"
[ -f .env ] && export $(grep -v '^#' .env | xargs)
echo "Installing deps (pehli baar 5-10 min lag sakta hai)…"
npm install
node -e "require('playwright').chromium.launch().then(b=>{console.log('Chromium OK');return b.close()}).catch(()=>{console.log('Chromium missing — chalao: npx playwright install chromium')})"
echo "Bridge: http://localhost:${PORT:-3000}/health"
node server.js
