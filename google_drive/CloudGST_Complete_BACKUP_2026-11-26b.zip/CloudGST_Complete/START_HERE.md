# 🚀 CloudGST — Complete Bundle (GitHub ke bina bhi sab chalu)

Ye bundle **self-contained** hai. GitHub, Railway, ya kuchh bhi delete ho jaye — sirf ye file upload karke sab dobara chalu ho jata hai.
**Is bundle me code bilkul wahi hai jo aaj chal raha hai** — kuchh badla nahi hai.

---

## 📦 Andar kya hai

| Folder | Kya hai | Kaam |
|---|---|---|
| `web/` | `index.html` (pura app) + 5 pages | Static site — jahan bhi upload karo, app chal jayega |
| `bridge/` | `server.js` + `package.json` + `Dockerfile` + `railway.json` + `render.yaml` + `.env.example` + `run-local.sh` | Portal se data laane wala server (Chromium) |
| `android/` | poora Android source + **`keystore.p12`** (signing key) | APK dobara banane ke liye (`android.yml` GitHub Actions ke saath) |
| `.github/workflows/android.yml` | CI | Repo me daalo -> push -> APK khud ban jayega |
| `apps-script/` | `APPS_SCRIPT_AppSync.gs`, `APPS_SCRIPT_gstr1_json_v5_8.gs` | Google Sheet / Drive wala hissa |
| `docs/` | deploy + fix notes | Troubleshooting |
| `checksums.txt` | SHA-256 | File sahi hai ya nahi, verify karne ke liye |

**Current versions:** app = `v5.9.14`, bridge = `1.29.1`, web `index.html` = 1,181,489 bytes.

---

## 1️⃣ Bridge server chalu karo (koi ek raasta)

### A) Render (sabse aasan — 3 click)
1. Ye bundle GitHub repo me daal do (ya Render par "Public Git repo" ki tarah)
2. render.com -> **New → Blueprint** -> repo -> **Apply**
3. Env `API_SECRET` = apna secret daalo -> deploy
4. URL milega: `https://xxxx.onrender.com` -> `/health` kholo

### B) Railway
1. Repo -> **+ New Project → Deploy from GitHub repo** (root me `Dockerfile` + `railway.json` hai)
2. **Variables**: `API_SECRET`, `ALLOWED_ORIGIN`, `NODE_ENV=production`, `MEM_LIMIT_MB=1200`
3. **Networking → Generate Domain** -> `/health` check
4. **Memory 2 GB** rakho (Chromium ke liye)

### C) Docker (apna server / VPS)
```bash
cd bridge
docker build -t cloudgst-bridge .
docker run -d -p 3000:3000 -e API_SECRET=apna-secret cloudgst-bridge
```

### D) PC / laptop (sirf testing)
```bash
cd bridge
cp .env.example .env      # API_SECRET daalo
./run-local.sh            # http://localhost:3000/health
```

**Sahi chalne ka proof** — `/health` par aisa dikhna chahiye:
```json
{"ok":true,"version":"1.29.1","secretConfigured":true,"uptimeSec":40,"chromiumUp":false}
```

---

## 2️⃣ Web app upload karo

`web/` ka **poora content** (root me `index.html` hona chahiye) upload karo:

- **Cloudflare Pages** — dashboard -> Pages -> Upload assets -> `web/` ka content
- **Cloudflare Workers** — worker -> assets -> upload `web/`
- **GitHub Pages** — repo me `web/` ka content root me (ya `/docs`) -> Settings -> Pages
- **Koi bhi hosting** (Hostinger, Netlify, cPanel) — bas static files

---

## 3️⃣ App ko bridge se jodo
App -> **GST Portal → ⚙️ Settings**:
- **Bridge Server URL** = step 1 ka URL (`https://…`)
- **API Secret** = wahi `API_SECRET`
- **Save & Test** -> phir **🩺 Bridge test** -> `✅ v1.29.1 · xx ms · uptime …`

`ALLOWED_ORIGIN` me apni site ka origin daalna (workers.dev / pages.dev khud allowed hain).

---

## 4️⃣ APK dobara banana ho
`android/` + `.github/workflows/android.yml` ko repo me daalo -> push -> Actions se APK ban jayega.
**`android/keystore.p12` sambhal ke rakho** — iske bina nayi APK purani ke upar install nahi hogi (signature mismatch).
Release APK: `https://github.com/adwikjais-code/cloudgst/releases/download/android-v5.9.14/CloudGST.apk`
(sha256 `fa670c3b…f8ace`, size 3,179,866 B — GitHub na rahe to APK dobara build karna padega.)

---

## 5️⃣ Google Sheet / Apps Script
`apps-script/APPS_SCRIPT_AppSync.gs` ko Apps Script editor me paste karo -> Deploy -> Web app -> URL copy -> app ki Settings me daalo.
Sheet: `GST Details` (tabs: PAID CLINTS, _PortalVault, _FeeLedger, _FeeProfiles, Apne).

---

## ⚠️ Zaroori baatein
- Ye bundle **private** rakho — isme `keystore.p12` (APK signing key) aur secret placeholders hain.
- `API_SECRET` kabhi public na karo (screenshot/WhatsApp me bhi nahi).
- Captcha/OTP aap hi daalenge — auto-solve **nahi**; portal par koi submit/ACCEPT app khud nahi karta.
- Sab kuch pahle jaisa hi hai: koi feature hataya nahi, koi behaviour badla nahi.
